﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication11.DAL
{
    public class DatabaseContext: DbContext
    {

       public  DatabaseContext() :base("DatabaseContext")
        {
            

        }
        public DbSet<Models.Tyre> Tyres { set; get; }
        public DbSet<Models.Sale> Sales { set; get; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        
    }
}