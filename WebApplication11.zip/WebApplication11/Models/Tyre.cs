﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication11.Models
{
    public class Tyre
    {

        [Key]
        public int TyresId { get; set; }


        public string Brand { get; set; }

        public string Country { get; set; }

        public int Size { get; set; }

        public string Condition { get; set; }


        public int Quantity { get; set; }


        public int PurchasePrice { get; set; }


        public int SellingPrice { get; set; }
    }
}