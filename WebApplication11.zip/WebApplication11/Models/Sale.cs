﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WebApplication11.Models
{
    public class Sale
    {
        [Key]
        public int SalesId { get; set; }


       // [ForeignKey("TyresId")]
        public int TyresId { get; set; }
        public Tyre tyre { get; set; }


        public int Quantity { get; set; }

        public string CustomerName { get; set; }

        public string TransactionDateTime { get; set; }

        public int CashRecieved { get; set; }
    }
}